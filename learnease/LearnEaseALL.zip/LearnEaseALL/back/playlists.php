<?php
// Suppress error display and enable error logging
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/error.log');
error_reporting(E_ALL);

include 'connect.php'; // Include your database connection file

// Fetch playlists from the database
$playlists = $conn->query("SELECT * FROM `playlist`")->fetchAll(PDO::FETCH_ASSOC);

// Handle playlist deletion
if (isset($_POST['delete_playlist'])) {
    $id = $_POST['id'];

    $delete_query = $conn->prepare("DELETE FROM `playlist` WHERE `id` = ?");
    $delete_query->execute([$id]);

    header('Location: playlists.php'); // Refresh the page
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Playlists</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: lightblue;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 1200px;
            margin: 20px auto;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            padding: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        th, td {
            text-align: left;
            padding: 12px;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #f8f8f8;
        }
        tr:hover {
            background-color: #f1f1f1;
        }
        .btn {
            padding: 8px 12px;
            font-size: 14px;
            color: #fff;
            border: none;
            cursor: pointer;
            border-radius: 4px;
            background-color: #dc3545;
        }
        .btn:hover {
            opacity: 0.9;
        }
        h1 {
            text-align: center;
            color: red;
        }
    </style>
</head>
<body>
<div class="container">
    <h1>Manage Playlists</h1>
    <h2>Playlist List</h2>
    <table>
        <thead>
        <tr>
            <th>ID</th>
            <th>Title</th>
            <th>Description</th>
            <th>Action</th>
        </tr>
        </thead>
        <tbody>
        <?php foreach ($playlists as $playlist): ?>
            <tr>
                <td><?= $playlist['id']; ?></td>
                <td><?= htmlspecialchars($playlist['title']); ?></td>
                <td><?= htmlspecialchars($playlist['description']); ?></td>
                <td>
                    <form method="post" style="display: inline;">
                        <input type="hidden" name="id" value="<?= $playlist['id']; ?>">
                        <button type="submit" name="delete_playlist" class="btn">Delete</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>
</body>
</html>
