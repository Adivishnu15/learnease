<?php
// Suppress error display and enable error logging
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/error.log');
error_reporting(E_ALL);

include 'connect.php'; // Include your database connection file

// Fetch users and tutors from the database
$users = $conn->query("SELECT * FROM `users`")->fetchAll(PDO::FETCH_ASSOC);
$tutors = $conn->query("SELECT * FROM `tutors`")->fetchAll(PDO::FETCH_ASSOC);

// Handle status update
if (isset($_POST['update_status'])) {
    $id = $_POST['id'];
    $status = $_POST['status'];
    $table = $_POST['table'];

    $update_query = $conn->prepare("UPDATE `$table` SET `status` = ? WHERE `id` = ?");
    $update_query->execute([$status, $id]);

    header('Location: admin.php'); // Refresh the page
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
    <!-- <link rel="stylesheet" href="style.css"> -->
    <style>
body {
    font-family: Arial, sans-serif;
    background-color: lightblue;
    margin: 0;
    padding: 0;
}
.container {
    max-width: 1200px;
    margin: 20px auto;
    background: #fff;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    padding: 20px;
}
table {
    width: 100%;
    border-collapse: collapse;
    margin: 20px 0;
}
th, td {
    text-align: left;
    padding: 12px;
    border-bottom: 1px solid #ddd;
}
th {
    background-color: #f8f8f8;
}
tr:hover {
    background-color: #f1f1f1;
}
.btn {
    padding: 8px 12px;
    font-size: 14px;
    color: #fff;
    border: none;
    cursor: pointer;
    border-radius: 4px;
}
.btn.active {
    background-color: #28a745;
}
.btn.inactive {
    background-color: #dc3545;
}
.btn:hover {
    opacity: 0.9;
}
h2 {
    margin: 0 0 20px;
}
h1 {
    text-align: center;
    color: red;
}
.manage {
    display: flex;
    justify-content: center;
    gap: 20px;
    margin: 40px auto;
}

.manage button {
    padding: 10px 20px;
    font-size: 16px;
    background-color: #007bff;
    color: #fff;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

.manage button:hover {
    background-color: lightcoral;
    color: #fff;
    opacity: 0.9;
}
</style>
       
</head>
<body>
<div class="container">
    <h1>ADMIN</h1>
    <h2>Users List</h2>
    <table>
        <thead>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Status</th>
            <th>Action</th>
        </tr>
        </thead>
        <tbody>
        <?php foreach ($users as $user): ?>
            <tr>
                <td><?= $user['id']; ?></td>
                <td><?= htmlspecialchars($user['name']); ?></td>
                <td><?= htmlspecialchars($user['email']); ?></td>
                <td><?= $user['status'] == 1 ? 'Active' : 'Inactive'; ?></td>
                <td>
                    <form method="post" style="display: inline;">
                        <input type="hidden" name="id" value="<?= $user['id']; ?>">
                        <input type="hidden" name="table" value="users">
                        <input type="hidden" name="status" value="<?= $user['status'] == 1 ? 0 : 1; ?>">
                        <button type="submit" name="update_status"
                                class="btn <?= $user['status'] == 1 ? 'inactive' : 'active'; ?>">
                            <?= $user['status'] == 1 ? 'Deactivate' : 'Activate'; ?>
                        </button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>

    <h2>Tutors List</h2>
    <table>
        <thead>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Status</th>
            <th>Action</th>
        </tr>
        </thead>
        <tbody>
        <?php foreach ($tutors as $tutor): ?>
            <tr>
                <td><?= $tutor['id']; ?></td>
                <td><?= htmlspecialchars($tutor['name']); ?></td>
                <td><?= htmlspecialchars($tutor['email']); ?></td>
                <td><?= $tutor['status'] == 1 ? 'Active' : 'Inactive'; ?></td>
                <td>
                    <form method="post" style="display: inline;">
                        <input type="hidden" name="id" value="<?= $tutor['id']; ?>">
                        <input type="hidden" name="table" value="tutors">
                        <input type="hidden" name="status" value="<?= $tutor['status'] == 1 ? 0 : 1; ?>">
                        <button type="submit" name="update_status"
                                class="btn <?= $tutor['status'] == 1 ? 'inactive' : 'active'; ?>">
                            <?= $tutor['status'] == 1 ? 'Deactivate' : 'Activate'; ?>
                        </button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>
<div class="manage" >
    <a href="playlists.php"><button>Manage Playlist</button></a>
    <a href="videos.php"><button>Manage videos</button></a>
    <a href="usersmanage.php"><button>Manage Accounts</button></a>
</div>
</body>
</html>
