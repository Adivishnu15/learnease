<?php
// Suppress error display and enable error logging
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/error.log');
error_reporting(E_ALL);

include 'connect.php'; // Include your database connection file

// Fetch users and tutors from the database
$users = $conn->query("SELECT * FROM `users`")->fetchAll(PDO::FETCH_ASSOC);
$tutors = $conn->query("SELECT * FROM `tutors`")->fetchAll(PDO::FETCH_ASSOC);

// Handle email deletion
if (isset($_POST['delete_email'])) {
    $id = $_POST['id'];
    $table = $_POST['table'];

    $delete_query = $conn->prepare("DELETE FROM `$table` WHERE `id` = ?");
    $delete_query->execute([$id]);

    header('Location: usersmanage.php'); // Refresh the page
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users and Tutors</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color:lightblue;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 1200px;
            margin: 20px auto;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            padding: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        th, td {
            text-align: left;
            padding: 12px;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #f8f8f8;
        }
        tr:hover {
            background-color: #f1f1f1;
        }
        .btn {
            padding: 8px 12px;
            font-size: 14px;
            color: #fff;
            border: none;
            cursor: pointer;
            border-radius: 4px;
            background-color: #dc3545;
        }
        .btn:hover {
            opacity: 0.9;
        }
        h1 {
            text-align: center;
            color: red;
        }
    </style>
</head>
<body>
<div class="container">
    <h1>Manage Users and Tutors</h1>

    <h2>Users List</h2>
    <table>
        <thead>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Action</th>
        </tr>
        </thead>
        <tbody>
        <?php foreach ($users as $user): ?>
            <tr>
                <td><?= $user['id']; ?></td>
                <td><?= htmlspecialchars($user['name']); ?></td>
                <td><?= htmlspecialchars($user['email']); ?></td>
                <td>
                    <form method="post" style="display: inline;">
                        <input type="hidden" name="id" value="<?= $user['id']; ?>">
                        <input type="hidden" name="table" value="users">
                        <button type="submit" name="delete_email" class="btn">Delete</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>

    <h2>Tutors List</h2>
    <table>
        <thead>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Action</th>
        </tr>
        </thead>
        <tbody>
        <?php foreach ($tutors as $tutor): ?>
            <tr>
                <td><?= $tutor['id']; ?></td>
                <td><?= htmlspecialchars($tutor['name']); ?></td>
                <td><?= htmlspecialchars($tutor['email']); ?></td>
                <td>
                    <form method="post" style="display: inline;">
                        <input type="hidden" name="id" value="<?= $tutor['id']; ?>">
                        <input type="hidden" name="table" value="tutors">
                        <button type="submit" name="delete_email" class="btn">Delete</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>
</body>
</html>
